var btn = document.getElementById('btn');
function kick(){
	document.getElementById("img11").src ="tinycard.png";
};